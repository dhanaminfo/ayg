const express = require("express");
const cors = require("cors");
const app = express();
const axios = require("axios");
const path = require("path");
const mysql = require("mysql2");
const nodemailer = require("nodemailer");
const bodyParser = require("body-parser");
const fs = require("fs");
const multer = require("multer");
const upload = multer({ dest: "uploads/" });
const proxy = require("express-http-proxy");
app.use(express.static(path.join(__dirname, "build")));

app.get("/sitemap.xml", (req, res) => {
  const pages = [
    { url: "/", changefreq: "weekly", priority: 1.0 },
    { url: "/yachts-for-sale", changefreq: "weekly", priority: 0.9 },
    { url: "/services", changefreq: "monthly", priority: 0.8 },
    { url: "/contact-us", changefreq: "monthly", priority: 0.8 },
    { url: "/hcb", changefreq: "monthly", priority: 0.7 },
    { url: "/39-speciale", changefreq: "monthly", priority: 0.7 },
    { url: "/42-lujo", changefreq: "monthly", priority: 0.7 },
    { url: "/48-campeon", changefreq: "monthly", priority: 0.7 },
    { url: "/53-suenos", changefreq: "monthly", priority: 0.7 },
    { url: "/65-estrella", changefreq: "monthly", priority: 0.7 },
    // { url: "/ikon", changefreq: "monthly", priority: 0.7 },
    { url: "/news-events", changefreq: "weekly", priority: 0.8 },
    {
      url: "/news-details/preparing-for-hurricane",
      changefreq: "monthly",
      priority: 0.5,
    },
    {
      url: "/news-details/39-turns-head",
      changefreq: "monthly",
      priority: 0.5,
    },
    {
      url: "/news-details/campeon-innovation-award",
      changefreq: "monthly",
      priority: 0.5,
    },
    {
      url: "/news-details/opening-of-new-office",
      changefreq: "monthly",
      priority: 0.5,
    },
    // { url: "/awake", changefreq: "monthly", priority: 0.6 },
    // { url: "/awake-jetboards", changefreq: "monthly", priority: 0.6 },
    // { url: "/awake-efoils", changefreq: "monthly", priority: 0.6 },
    // { url: "/marketing-policy", changefreq: "monthly", priority: 0.3 },
    // { url: "/privacy-policy", changefreq: "monthly", priority: 0.3 },
  ];

  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
  pages.forEach((page) => {
    xml += `<url>
          <loc>https://www.americanyachtgroup.com${page.url}</loc>
          <changefreq>${page.changefreq}</changefreq>
          <priority>${page.priority}</priority>
      </url>\n`;
  });
  xml += "</urlset>";

  res.header("Content-Type", "application/xml");
  res.send(xml);
});

const allowedOrigins = [
  "http://18.223.93.100",
  "http://localhost:3000",
  "http://3.130.189.92",
  "https://www.megasails.com",
];

const corsOptions = {
  origin: function (origin, callback) {
    if (allowedOrigins.indexOf(origin) !== -1 || !origin) {
      callback(null, true);
    } else {
      callback(new Error("Not allowed by CORS"));
    }
  },
  methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
  credentials: true,
  optionsSuccessStatus: 204,
};
app.use(cors());
app.use(bodyParser.json());

app.use(
  [
    "/chatbot",
    "/vassar.runtime.*.js",
    "/vassar.polyfills.*.js",
    "/vassar.main.*.js",
    "/vassar.scripts.*.js",
    "/vassar.styles.*.css",
    "/assets/imgs/*",
    "/bootstrap-icons.*",
  ],

  proxy("https://ayg.ce.vassardigital.ai", {
    proxyReqPathResolver: (req) => {
      // Map to corresponding paths on the target server
      const updatedPath = req.originalUrl;
      console.log(`Proxying request to: ${updatedPath}`);
      return updatedPath;
    },
    proxyReqOptDecorator: (proxyReqOpts) => {
      proxyReqOpts.rejectUnauthorized = false; // Ignore self-signed certificates
      return proxyReqOpts;
    },
    userResDecorator: (proxyRes, proxyResData, req, res) => {
      console.log(`Response received for: ${req.url}`);
      return proxyResData;
    },
    proxyErrorHandler: (err, res) => {
      console.error("Proxy error:", err);
      res.status(500).json({ error: "Proxy error occurred" });
    },
  })
);

const APP_ID = "1044118127184848";
const APP_SECRET = "2a575d1566e2096a9ebbbf498ed45be1";
const REDIRECT_URI = "https://www.americanyachtgroup.com/";

// Endpoint to exchange code for an access token
app.post("/exchange-token", async (req, res) => {
  const { code } = req.body;

  try {
    const response = await axios.post(
      "https://api.instagram.com/oauth/access_token",
      null,
      {
        params: {
          client_id: APP_ID,
          client_secret: APP_SECRET,
          grant_type: "authorization_code",
          redirect_uri: REDIRECT_URI,
          code: code,
        },
      }
    );

    const { access_token, user_id } = response.data;
    res.status(200).json({ access_token, user_id });
  } catch (error) {
    console.error("Error exchanging token:", error.response.data);
    res.status(500).json({ error: "Failed to exchange token" });
  }
});

// Endpoint to fetch Instagram media
app.get("/get-media", async (req, res) => {
  const { access_token } = req.query;

  try {
    const response = await axios.get(`https://graph.instagram.com/me/media`, {
      params: {
        fields: "id,caption,media_type,media_url,thumbnail_url,permalink",
        access_token,
      },
    });

    res.status(200).json(response.data);
  } catch (error) {
    console.error("Error fetching media:", error.response.data);
    res.status(500).json({ error: "Failed to fetch media" });
  }
});

// Create MySQL connection
const db = mysql.createConnection({
  host: "ayg.cbg06c4m01qt.us-east-2.rds.amazonaws.com",
  user: "admin",
  password: "Ayg#$2024",
  database: "ayg_leads",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

db.connect((err) => {
  if (err) {
    console.error("Database connection failed:", err.stack);
    return;
  }
  console.log("Connected to database.");
});

app.post("/api/submit-form", (req, res) => {
  const formData = req.body;

  if (!formData) {
    return res.status(400).json({ error: "Form data is missing or undefined" });
  }

  // Remove non-numeric characters from phone number
  const phoneNumber = formData.NO_phoneNumber
    ? formData.NO_phoneNumber.replace(/\D/g, "")
    : "";

  const {
    NM_firstName = "",
    NM_lastName = "",
    ID_email = "",
    CD_city = "",
    CD_state = "",
    CD_country = "",
    CA_category = "",
    DS_comments1 = "",
    DS_comments2 = "",
    NM_docId = "",
    submitDateTime = new Date(),
  } = formData;

  const query = `
    INSERT INTO inquiries (
      NM_firstName, NM_lastName, ID_email, NO_phoneNumber,
      CD_city, CD_state, CD_country, CA_category,
      DS_comments1, DS_comments2, NM_docId, submitDateTime
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  const values = [
    NM_firstName,
    NM_lastName,
    ID_email,
    phoneNumber,
    CD_city,
    CD_state,
    CD_country,
    CA_category,
    DS_comments1,
    DS_comments2,
    NM_docId,
    submitDateTime,
  ];

  db.query(query, values, (err, result) => {
    if (err) {
      console.error("Error inserting data into the database:", err);
      return res
        .status(500)
        .json({ error: "Error inserting data into the database" });
    }
    res.json({ message: "Form submitted successfully" });
  });
});

// corsOptions
const transporter = nodemailer.createTransport({
  host: "smtp.office365.com",
  port: 587,
  secure: false,
  auth: {
    user: "sales@americanyachtgroup.com",
    pass: "HCB#$2024",
  },
});

app.post("/api/send-email-yachtdetails*", async (req, res) => {
  try {
    const { recipientEmail, subject, message } = req.body;

    if (!recipientEmail || !subject || !message) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    const {
      NM_firstName,
      NM_lastName,
      ID_email,
      NO_phoneNumber,
      CA_category,
      DS_comments1,
      NM_docId,
    } = message;

    const mailOptions = {
      from: "sales@americanyachtgroup.com",
      to: recipientEmail,
      subject: "American Yacht Group - Yacht Broker Services",
      text: `
Dear ${NM_firstName} ${NM_lastName},

Thank you for choosing American Yacht Group for your yacht broker services. Our dedicated Yacht Experts will contact you soon.

Best Regards,
American Yacht Group
      `,
    };
    const mailOptions1 = {
      from: "sales@americanyachtgroup.com",
      to: "sales@americanyachtgroup.com",
      cc: "Aygadmin@hcbyachts.com, leads@hcbyachts.com",
      subject: "American Yacht Group - Yacht Broker Services",
      text: `
Team,

Please find the details of the new lead from our AYG broker site for Yacht Broker service to review and process.
      
Lead Details:
    Name: ${NM_firstName} ${NM_lastName}
    Email: ${ID_email}
    Phone: ${NO_phoneNumber}
    Category: ${CA_category}    
    DocId:${NM_docId}
    Link: https://www.americanyachtgroup.com/yachtdetails/${NM_docId}
    Comments: ${DS_comments1}
    
Thank you
AYG Webmaster.
          `,
    };

    // Send email
    await transporter.sendMail(mailOptions); //Customer
    await transporter.sendMail(mailOptions1); //AYG team

    console.log("Email sent successfully");
    res.json({ success: true, message: "Email sent successfully" });
  } catch (error) {
    console.error("Error sending email:", error);
    res.status(500).json({ error: error.message || "An error occurred" });
  }
});

app.post("/api/send-email-contact*", async (req, res) => {
  try {
    const { recipientEmail, subject, message } = req.body;

    if (!recipientEmail || !subject || !message) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    const {
      NM_firstName,
      NM_lastName,
      ID_email,
      NO_phoneNumber,
      CA_category,
      DS_comments1,
    } = message;

    const mailOptions2 = {
      from: "sales@americanyachtgroup.com",
      to: recipientEmail,
      subject: "American Yacht Group - Yacht Contact Inquiry",
      text: `
Dear ${NM_firstName} ${NM_lastName},

Thank you for choosing American Yacht Group for your yacht brokerage services. Our dedicated Yacht Experts will contact you soon.

Best Regards,
American Yacht Group
      `,
    };
    const mailOptions3 = {
      from: "sales@americanyachtgroup.com",
      to: "sales@americanyachtgroup.com",
      cc: "Aygadmin@hcbyachts.com, leads@hcbyachts.com",
      subject: "American Yacht Group - Yacht Contact Inquiry",
      text: `
Team,

Please find the details of the new lead from our AYG broker site for Yacht Broker & Services to review and process.

Lead Details:
    Name: ${NM_firstName} ${NM_lastName}
    Email: ${ID_email}
    Phone: ${NO_phoneNumber}
    Category: ${CA_category}
    Comments: ${DS_comments1} 
    
Thank you
AYG Webmaster.
          `,
    };

    // Send email
    await transporter.sendMail(mailOptions2); //Customer
    await transporter.sendMail(mailOptions3); //AYG team

    console.log("Email sent successfully");
    res.json({ success: true, message: "Email sent successfully" });
  } catch (error) {
    console.error("Error sending email:", error);
    res.status(500).json({ error: error.message || "An error occurred" });
  }
});

app.post("/api/send-email-service*", async (req, res) => {
  try {
    const { recipientEmail, subject, message } = req.body;

    if (!recipientEmail || !subject || !message) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    const {
      NM_firstName,
      NM_lastName,
      ID_email,
      NO_phoneNumber,
      CA_category,
      DS_comments1,
    } = message;

    const mailOptions4 = {
      from: "sales@americanyachtgroup.com",
      to: recipientEmail,
      subject: "American Yacht Group - Yacht Service Inquiry",
      text: `
Dear ${NM_firstName} ${NM_lastName},

Thank you for choosing American Yacht Group for your yacht ${CA_category} services.Our dedicated Yacht Experts will contact you soon.

Best Regards,
American Yacht Group
      `,
    };
    const mailOptions5 = {
      from: "sales@americanyachtgroup.com",
      to: "sales@americanyachtgroup.com",
      cc: "Aygadmin@hcbyachts.com, leads@hcbyachts.com",
      subject: "American Yacht Group - Yacht Service Inquiry",
      text: `
Team,

Please find the details of the new lead from our AYG broker site for ${CA_category} service to review and process.

Lead Details:
    Name: ${NM_firstName} ${NM_lastName}
    Email: ${ID_email}
    Phone: ${NO_phoneNumber}
    Category: ${CA_category}
    Comments: ${DS_comments1}  

Thank you
AYG Webmaster.  
  `,
    };

    // Send email
    await transporter.sendMail(mailOptions4); //Customer
    await transporter.sendMail(mailOptions5); //AYG team

    console.log("Email sent successfully");
    res.json({ success: true, message: "Email sent successfully" });
  } catch (error) {
    console.error("Error sending email:", error);
    res.status(500).json({ error: error.message || "An error occurred" });
  }
});

app.post(
  "/api/send-email-careers",
  upload.single("FL_file"),
  async (req, res) => {
    try {
      const {
        NM_firstName,
        NM_lastName,
        ID_email,
        NO_phoneNumber,
        CA_category,
        DS_comments1,
      } = req.body;
      const file = req.file;

      const mailOptions6 = {
        from: "sales@americanyachtgroup.com",
        to: ID_email,
        subject: "Application Submission",
        text: `
Dear ${NM_firstName} ${NM_lastName},

Thank you for submitting your application. Our HR specialist will contact you at the earliest.
      
Best Regards,
American Yacht Group, HR Team
      `,
        // attachments: [
        //   {
        //     filename: file.originalname,
        //     content: fs.readFileSync(file.path),
        //   },
        // ],
      };
      const mailOptions7 = {
        from: "sales@americanyachtgroup.com",
        to: "sales@americanyachtgroup.com",
        cc: "Aygadmin@hcbyachts.com",
        subject: "American Yacht Group - Yacht Broker Services",
        text: `
Team,

Please find the applicant details and the resume for the job listing "${CA_category}" received to review and process.

Applicant Details:
    Name: ${NM_firstName} ${NM_lastName}
    Email: ${ID_email}
    Phone: ${NO_phoneNumber}
    Category: ${CA_category}
    Comments: ${DS_comments1} 

Thank you
AYG Webmaster  
          `,
        attachments: [
          {
            filename: file.originalname,
            content: fs.readFileSync(file.path),
          },
        ],
      };
      // Send email
      await transporter.sendMail(mailOptions6); //Candidate
      await transporter.sendMail(mailOptions7); //AYG Team

      console.log("Email sent successfully");
      res.json({ success: true, message: "Email sent successfully" });
    } catch (error) {
      console.error("Error sending email:", error);
      res.status(500).json({ error: error.message || "An error occurred" });
    }
  }
);

app.post("/api/send-email-subscribers", async (req, res) => {
  try {
    const { email, verificationToken, verificationURL } = req.body;

    if (!email) {
      return res.status(400).json({ error: "Email is required" });
    }

    const mailOptions8 = {
      from: "sales@americanyachtgroup.com",
      to: email,
      subject: "American Yacht Group - Thank You for Subscribing",
      html: `
      <p>Dear Subscriber,</p>
      <p>Thank you for subscribing to American Yacht Group's newsletter. You will now receive regular updates and news about our services and offers.</p>
      <p>Please click on the following link to verify your email:</p>
      <a href="${verificationURL}" style="display: inline-block; background-color: #007bff; color: #ffffff; text-decoration: none; padding: 10px 20px; border-radius: 5px; margin-top: 10px;">Verify Email</a>
      <p>Best Regards,<br>American Yacht Group</p>
    `,
    };

    await transporter.sendMail(mailOptions8);

    console.log("Email sent successfully");
    res.json({ success: true, message: "Email sent successfully" });
  } catch (error) {
    console.error("Error sending email:", error);
    res.status(500).json({ error: error.message || "An error occurred" });
  }
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/api/documents*", async (req, res) => {
  try {
    const {
      start = 0,
      rows = 25,
      make = null,
      condition = null,
      boatClass = null,
      length = null,
      price = null,
      year = null,
      DocumentID = null,
    } = req.query;
    const response = await axios.get(
      "https://services.boats.com/pls/boats/search",
      {
        params: {
          fields:
            "DocumentID,numResults,CompanyName,LengthOverall,NumberOfEngines,AdditionalDetailDescription,TotalEnginePowerQuantity,length,owner,LengthOverall,OwnerPartyID,salesrep,SalesRepPartyID,ModelYear,make,MakeString,Model,Images,BoatName,BoatLocation,SaleClassCode,BoatClassCode,Office,PriceHideInd,Price,GeneralBoatDescription,EmbeddedVideoPresent,video,EmbeddedVideo,price=${minPrice}:${maxPrice}|USD,length=${minLength}:${maxLength},year=${minYear}:${maxYear},price=${minPrice}:${maxPrice}|USD",
          key: "gs4g3hpp688c",
          start,
          rows,
          make,
          condition,
          price,
          length,
          year,
          sort: "ModelYear|desc",
          class: boatClass,
          DocumentID,
        },
      }
    );

    const responseData = response.data.data.results.map((result) => {
      const {
        DocumentID,
        CompanyName,
        owner,
        length,
        OwnerPartyID,
        salesrep,
        SalesRepPartyID,
        ModelYear,
        MakeString,
        NumberOfEngines,
        LengthOverall,
        TotalEnginePowerQuantity,
        AdditionalDetailDescription,
        Model,
        Images,
        BoatName,
        BoatLocation,
        SaleClassCode,
        BoatClassCode,
        Office,
        PriceHideInd,
        EmbeddedVideoPresent,
        video,
        EmbeddedVideo,
        Price,
        GeneralBoatDescription,
      } = result;

      return {
        DocumentID,
        CompanyName,
        owner,
        length,
        OwnerPartyID,
        LengthOverall,
        NumberOfEngines,
        TotalEnginePowerQuantity,
        AdditionalDetailDescription,
        salesrep,
        SalesRepPartyID,
        ModelYear,
        MakeString,
        Model,
        Images,
        BoatName,
        BoatLocation,
        SaleClassCode,
        BoatClassCode,
        Office,
        PriceHideInd,
        Price,
        EmbeddedVideoPresent,
        video,
        EmbeddedVideo,
        GeneralBoatDescription,
      };
    });

    const numResults = response.data.data.numResults;
    const totalPages = Math.ceil(numResults / rows);

    res.json({ data: { results: responseData, numResults, totalPages } });
  } catch (error) {
    res.status(500).json({ error: error.message || "An error occurred" });
  }
});

app.get("/api/unique-makes*", async (req, res) => {
  try {
    const uniqueMakesSet = new Set();

    // Make multiple requests with pagination parameters
    const rowsPerPage = 25;
    const response = await axios.get(
      "https://services.boats.com/pls/boats/search",
      {
        params: {
          fields: "MakeString",
          key: "gs4g3hpp688c",
          rows: rowsPerPage,
          start: 0, // Always start from the beginning for unique-makes
        },
      }
    );

    const totalPages = Math.ceil(response.data.data.numResults / rowsPerPage);

    for (let page = 1; page <= totalPages; page++) {
      const response = await axios.get(
        "https://services.boats.com/pls/boats/search",
        {
          params: {
            fields: "MakeString",
            key: "gs4g3hpp688c",
            rows: rowsPerPage,
            start: (page - 1) * rowsPerPage,
          },
        }
      );

      const makes = response.data.data.results.map(
        (result) => result.MakeString
      );

      makes.forEach((make) => uniqueMakesSet.add(make));
    }

    const uniqueMakesArray = Array.from(uniqueMakesSet);

    res.json({ data: { uniqueMakes: uniqueMakesArray } });
  } catch (error) {
    res.status(500).json({ error: error.message || "An error occurred" });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "build", "index.html"));
});

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
